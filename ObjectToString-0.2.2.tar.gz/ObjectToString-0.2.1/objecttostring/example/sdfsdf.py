class sdfsdf:
	def __init__(self):
		self.a=None
		self.c=None
		self.d=None
	def seta(self,a):
		self.a=a
	def geta(self):
		return self.a
	def setc(self,c):
		self.c=c
	def getc(self):
		return self.c
	def setd(self,d):
		self.d=d
	def getd(self):
		return self.d
