import ObToStr
tts=ObToStr.ObjectToStr()
tts.generalPy("dddd","sdfsdf",".")


import example.sdfsdf
mm= example.sdfsdf.sdfsdf()
mm.seta(111.0396)
mm.setc(None)

a,b=tts.generalStr(mm)
print a
print b